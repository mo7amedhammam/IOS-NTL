//
//  Pin.swift
//  VirtualTourist
//
//  Created by Mohamed Hammam on 2/22/19.
//  Copyright © 2019 mohamed hammam. All rights reserved.
//

import Foundation
import CoreData

//Pin Class

public class Pin: NSManagedObject {
    
    convenience init?(latitude: Double, longitude: Double, context: NSManagedObjectContext) {
        
        if let ent = NSEntityDescription.entity(forEntityName: "Pin", in: context) {
            
            self.init(entity: ent, insertInto: context)
            self.latitude   = latitude
            self.longitude  = longitude
            
        } else {
            return nil
            //fatalError("Unable To Find Entity Name!")
        }
    }
    
}

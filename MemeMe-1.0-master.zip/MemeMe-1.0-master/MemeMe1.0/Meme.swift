//
//  Meme.swift
//  MemeMe1.0
//
//  Created by Gil Felot on 25/08/15.
//  Copyright (c) 2015 Gil Felot. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var topText: String
    var botText: String
    var originalImage: UIImage
    var memedImage : UIImage
    
//    init (topText: String, botText: String, originalImage: UIImage, memedImage: UIImage) {
//        self.topText = topText
//        self.botText = botText
//        self.originalImage = originalImage
//        self.memedImage = memedImage
//    }
}

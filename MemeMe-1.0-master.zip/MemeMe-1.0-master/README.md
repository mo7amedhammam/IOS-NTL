# MemeMe-1.0
A meme generator in Swift - v1 of the second app for Udacity's iOS Nanodegree program
//
//  UdacitySession.swift
//  On the Map
//
//  Created by Mohamed Hammam on 03/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation

struct UdacitySession: Decodable {
    
    let account: Account
    let session: Session
    
    struct Account: Decodable {
        let registered: Bool
        let key: String
    }
    
    struct Session: Decodable {
        let id: String
        let expiration: String
    }
    
}

//
//  StudentInformationModel.swift
//  On the Map
//
//  Created by Mohamed Hammam on 03/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation

struct StudentInformationModel {
    
    var studentInformations: [StudentInformation]
    
}

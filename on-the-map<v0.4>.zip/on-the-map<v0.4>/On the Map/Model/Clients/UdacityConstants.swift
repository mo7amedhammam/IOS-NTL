//
//  UdacityConstants.swift
//  On the Map
//
//  Created by Mohamed Hammam on 03/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation

extension UdacityClient {
    
    // MARK: Constants
    struct Constants {
        
        // MARK: URLs
        static let ApiScheme = "https"
        static let ApiHost = "onthemap-api.udacity.com"
        static let ApiPath = "v1"
    }
    
    // MARK: Methods
    
    struct Methods {
        static let Session = "session"
        static let Users = "users"
        static let UsersID = "users/{id}"
    }
    
    // MARK: URL Keys
    struct URLKeys {
        static let UserID = "id"
    }
    
    // MARK: Parameter Keys
    
    struct ParameterKeys {
        static let Username = "username"
        static let Password = "password"
    }
}

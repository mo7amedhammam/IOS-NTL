//
//  FailableView.swift
//  On the Map
//
//  Created by Mohamed Hammam on 03/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//
import UIKit

protocol FailableView {
    
    func displayFailureAlert(title: String?, error: String)
}

extension FailableView where Self: UIViewController {
    
    func displayFailureAlert(title: String?, error: String) {
        let alertViewController = UIAlertController(title: title, message: error, preferredStyle: .alert)
        alertViewController.addAction(UIAlertAction(title: NSLocalizedString("Ok", comment: ""), style: .default, handler: nil))
        
        present(alertViewController, animated: true, completion: nil);
    }
}

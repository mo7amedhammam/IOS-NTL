//
//  TabViewController.swift
//  On the Map
//
//  Created by Mohamed Hammam on 03/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import UIKit

protocol StudentInformationPresenter: LoadableView, FailableView {
    
}

class TabBarController: UITabBarController, FailableView {
    
    var studentsViewControllers: [StudentInformationPresenter] {
        return self.viewControllers as! [StudentInformationPresenter]
    }
    
    var selectedStudentViewController: StudentInformationPresenter {
        return studentsViewControllers[selectedIndex]
    }
    
    //MARK: UIViewController
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getStudentsLocation()
    }
    
    //MARK: Setup
    
    func setupMapViewData(with data: StudentInformationModel?) {
        let mapViewController = viewControllers?.first as! MapViewController
        mapViewController.theData = data
    }
    
    func setupTableViewData(with data: StudentInformationModel?) {
        let tableViewController = viewControllers?.last as! TableViewController
        tableViewController.theData = data
        if tableViewController.isViewLoaded {
            tableViewController.tableView.reloadData()
        }
    }
    
    //MARK: Actions
    
    @IBAction func logout(_ sender: UIBarButtonItem) {
        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
        request.httpMethod = "DELETE"
        var xsrfCookie: HTTPCookie? = nil
        let sharedCookieStorage = HTTPCookieStorage.shared
        for cookie in sharedCookieStorage.cookies! {
            if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
        }
        if let xsrfCookie = xsrfCookie {
            request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
        }
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if error != nil { // Handle error…
                return
            }
            let range = Range(5..<data!.count)
            let newData = data?.subdata(in: range) /* subset response data! */
            print(String(data: newData!, encoding: .utf8)!)
        }
        task.resume()
        
//        let userDefaults = UserDefaults.standard
//        userDefaults.removeObject(forKey: "userSession")
//        userDefaults.synchronize()
//
//        var request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/session")!)
//        request.httpMethod = "DELETE"
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func refresh(_ sender: UIBarButtonItem) {
        getStudentsLocation()
    }
    
    // MARK: Networking
    
    func getStudentsLocation() {
        selectedStudentViewController.showLoadingView()
        
        ParseClient.shared().getStudentLocation { (studentInformation, error) in
            
            DispatchQueue.main.async {
                self.selectedStudentViewController.dismissLoadingView()
                
                if let error = error {
                    self.displayFailureAlert(title: nil, error: error.localizedDescription)
                    
                } else if let studentInformation = studentInformation {
                    let model = StudentInformationModel(studentInformations: studentInformation)
                    
                    self.setupMapViewData(with: model)
                    self.setupTableViewData(with: model)
                }
            }
        }
    }
    
    
}

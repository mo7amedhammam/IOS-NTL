//
//  Constants.swift
//  JSON Feed Reader
//
//  Created by Mohamed Hammam on 3/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation

class JsonFeedOrg {
    static let WEBSITE = "https://jsonfeed.org/"
    static let SPECIFICATIONS = "https://jsonfeed.org/version/1"
    static let FEED = "https://jsonfeed.org/feed.json"
}

enum Errors: Error {
    case NetworkError
    case ServerError
    case LocalDatabaseError
    case EmptyDatabaseError
    case UnknownError
}

//
//  LocalRepository.swift
//  JSON Feed Reader
//
//  Created by Mohamed Hammam on 3/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation
import CoreData

class LocalRepository: RepositoryProtocol {
    
    var dataController: DataController
    
    init(dataController: DataController) {
        self.dataController = dataController
    }
    
    func loadPosts(feed: Feed, onError: @escaping ErrorCallback, onPostsLoaded: @escaping PostsCallback) {
        if !dataController.isLoaded {
            onError(Errors.LocalDatabaseError)
            return
        }
        
        let fetchRequest: NSFetchRequest<Post> = Post.fetchRequest()
        do {
            let results = try dataController.viewContext.fetch(fetchRequest)
            print("Loaded posts from local db with count \(results.count)")
            if results.count <= 0 {
                throw Errors.EmptyDatabaseError
            }
            onPostsLoaded(results)
        } catch {
            print("Fetch Error")
            onError(Errors.LocalDatabaseError)
        }
    }
    
    func loadContent(postId: String, onError: @escaping ErrorCallback, onContentLoaded: @escaping ContentCallback) {
        if !dataController.isLoaded {
            onError(Errors.LocalDatabaseError)
            return
        }
    }
}

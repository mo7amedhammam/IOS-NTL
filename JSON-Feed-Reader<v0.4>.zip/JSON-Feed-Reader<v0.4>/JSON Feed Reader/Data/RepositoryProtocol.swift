//
//  RepositoryProtocol.swift
//  JSON Feed Reader
//
//  Created by Mohamed Hammam on 3/03/19.
//  Copyright © 2019 Mohamed Hammam. All rights reserved.
//

import Foundation

protocol RepositoryProtocol {
    
    typealias ErrorCallback = ((Errors) -> Void)
    
    typealias PostsCallback = (([Post]) -> Void)
    typealias PostCallback = ((Post) -> Void)
    typealias ContentCallback = ((String) -> Void)
    
    func loadPosts(feed: Feed, onError: @escaping ErrorCallback, onPostsLoaded: @escaping PostsCallback)
    
    func loadContent(postId: String, onError: @escaping ErrorCallback, onContentLoaded: @escaping ContentCallback)
}

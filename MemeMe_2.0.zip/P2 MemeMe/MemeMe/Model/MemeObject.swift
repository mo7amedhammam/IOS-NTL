//
//  MemeObject.swift
//  MemeMe
//
//  Created by mohamed on 1/27/19.
//  Copyright © 2019 mohamed. All rights reserved.
//

import Foundation
import UIKit

struct MemeObject {
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}

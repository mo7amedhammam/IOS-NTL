//
//  MemeCollectionViewCell.swift
//  MemeMe
//
//  Created by mohamed on 1/27/19.
//  Copyright © 2019 mohamed. All rights reserved.
//

import UIKit

class MemeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}

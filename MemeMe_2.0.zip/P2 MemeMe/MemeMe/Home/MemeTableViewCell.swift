//
//  MemeTableViewCell.swift
//  MemeMe
//
//  Created by mohamed on 1/27/19.
//  Copyright © 2019 mohamed. All rights reserved.
//

import Foundation
import UIKit

class MemeTableViewCell: UITableViewCell {
    
    @IBOutlet weak var memeImageView: UIImageView!
    @IBOutlet weak var memeTitleLabel: UILabel!
}
